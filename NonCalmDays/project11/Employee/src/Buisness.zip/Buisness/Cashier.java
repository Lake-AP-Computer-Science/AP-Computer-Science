package Buisness;

public class Cashier extends StoreClerk {

	public Cashier(String name, int ID, int yearsWorked) {
		super(name, ID, yearsWorked);
		// TODO Auto-generated constructor stub
	}
}
