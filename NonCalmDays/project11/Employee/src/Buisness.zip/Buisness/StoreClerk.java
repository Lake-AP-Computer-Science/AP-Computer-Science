package Buisness;

public class StoreClerk extends Employee {

	public StoreClerk(String name, int ID, int yearsWorked) {
		super(name, ID, yearsWorked);
		// TODO Auto-generated constructor stub
	}

}
