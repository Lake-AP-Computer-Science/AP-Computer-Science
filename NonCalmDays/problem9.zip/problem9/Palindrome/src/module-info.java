module Palindrome {
}