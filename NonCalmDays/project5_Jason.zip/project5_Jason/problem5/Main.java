package problem5;

import javax.swing.JFrame;

public class Main 
{
	public static void main(String[] args) 
	{
		ColorDisplay app = new ColorDisplay();
		app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
