package project4;

import java.util.ArrayList;

public class CircularLinkedList {
	private Node start, end;
	private ArrayList<Node> nodes = new ArrayList<Node>();
	 //adds the Node to the list based on the case/crime priority
	//and sets its court date by calling the method below [10 points]
	 public void add(Node node)
	 {
	 }
	 //sets the case Date based on the case priority [7 points]
	 private void setCaseDate()
	{
	}
	//prints the list from start to end [5 points]
	 public void printList()
	 {
	 }
}
